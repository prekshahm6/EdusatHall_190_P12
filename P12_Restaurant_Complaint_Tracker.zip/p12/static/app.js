const $=s=>document.querySelector(s), api=(u,m='GET',b)=>fetch(u,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined}).then(r=>r.json());
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const tag=p=>`<span class="tag ${esc(p)}">${esc(p)}</span>`;
const tbl=(cols,rows)=>`<div class="tbl"><table><tr>${cols.map(c=>`<th>${c[0]}</th>`).join('')}</tr>${rows.map(r=>`<tr>${cols.map(c=>`<td>${c[1](r)}</td>`).join('')}</tr>`).join('')||'<tr><td colspan="9">Nothing here yet.</td></tr>'}</table></div>`;
const charts={};
document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>show(b.dataset.t));
function show(t){document.querySelectorAll('main>section').forEach(s=>s.hidden=s.id!==t);document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));({user:loadUser,handler:loadHandler,routing:loadRouting,analytics:loadAnalytics}[t]||(()=>{}))()}
// Submit
let vt;$('#cid').oninput=()=>{clearTimeout(vt);vt=setTimeout(async()=>{const v=await api('/api/validate','POST',{complaint_id:$('#cid').value});
 $('#vmsg').innerHTML=!$('#cid').value?'Format: COMP-DDMMYYYY-ABC1234':v.valid?`<span class="ok">Valid. DFA and regex agree.</span>`:`<span class="bad">${esc(v.reason)}</span> (DFA: ${v.dfa?'accept':'reject'}, regex: ${v.regex?'accept':'reject'})`;
 $('#trace').textContent='q'+v.trace.join(' -> q').replace('q-1','DEAD')},250)};
let ct;const cls=()=>{clearTimeout(ct);ct=setTimeout(async()=>{if(!$('#desc').value)return;const c=await api('/api/classify','POST',{description:$('#desc').value,urgency:$('#urg').value});
 $('#cls').innerHTML=c.category?`Detected: <b>${esc(c.category)}</b> ${tag(c.priority)}${c.matched.length>1?' (also matched: '+esc(c.matched.slice(1).join(', '))+')':''}`:'No category detected. Report will go to manual review.'},250)};
$('#desc').oninput=cls;$('#urg').onchange=cls;
$('#f').onsubmit=async e=>{e.preventDefault();const r=await api('/api/reports','POST',{complaint_id:$('#cid').value.trim(),reporter_name:$('#rn').value,reporter_contact:$('#rc').value,description:$('#desc').value,urgency:$('#urg').value});
 if(!r.ok){$('#res').innerHTML=`<p class="bad"><b>Rejected:</b> ${esc(r.error)}</p>`;return}
 const p=r.report;$('#res').innerHTML=`<p class="ok"><b>Registered as ${esc(p.report_id)}</b></p><p>Category: <b>${esc(p.category||'Unclassified')}</b> ${tag(p.priority)}<br>Zone: ${esc(p.zone)}<br>Status: <b>${esc(p.status)}</b><br>Routing: ${esc(p.routing_decision)}${p.sla_due?`<br>48-hour SLA due: ${esc(p.sla_due)}`:''}</p>`;$('#f').reset();$('#cls').textContent='';};
// User
const rcols=[['Report',r=>esc(r.report_id)],['Complaint ID',r=>esc(r.complaint_id)],['Category',r=>esc(r.category||'Unclassified')],['Priority',r=>tag(r.priority)],['Status',r=>esc(r.status)],['Handler',r=>esc(r.handler_name)],['Submitted',r=>esc(r.created_at)]];
async function loadUser(q=''){const rows=await api('/api/reports'+(q?`?q=${encodeURIComponent(q)}`:''));const all=q?await api('/api/reports'):rows;
 const n=s=>all.filter(r=>r.status===s).length;$('#ustats').innerHTML=[['Total',all.length],['Pending',n('Pending')],['Assigned',n('Assigned')+n('In Progress')],['Resolved',n('Resolved')]].map(s=>`<div class="stat">${s[0]}<b>${s[1]}</b></div>`).join('');$('#ulist').innerHTML=tbl(rcols,rows)}
$('#qb').onclick=()=>loadUser($('#q').value.trim());
// Handler
async function loadHandler(){const hs=await api('/api/handlers');const cur=$('#hsel').value||hs[0].id;$('#hsel').innerHTML=hs.map(h=>`<option value="${h.id}" ${h.id===cur?'selected':''}>${esc(h.name)} (${esc(h.zone)})</option>`).join('');
 const h=hs.find(x=>x.id===$('#hsel').value);$('#hav').checked=!!h.available;$('#hcap').value=h.capacity;$('#hload').textContent=`Current load: ${h.load} of ${h.capacity}`;
 const rows=await api('/api/reports?handler='+h.id);$('#hlist').innerHTML=tbl([...rcols.slice(0,1),['Category',r=>esc(r.category||'-')],['Zone',r=>esc(r.zone)],['Priority',r=>tag(r.priority)],['Submitted',r=>esc(r.created_at)],['Status',r=>esc(r.status)],
 ['Update',r=>r.status==='Resolved'?'Done':`<select onchange="setSt('${r.report_id}',this.value)"><option value="">Change...</option>${r.status==='Assigned'?'<option>In Progress</option>':''}<option>Resolved</option></select>`]],rows)}
$('#hsel').onchange=loadHandler;
$('#hsave').onclick=async()=>{const r=await api('/api/handlers/'+$('#hsel').value,'PATCH',{available:$('#hav').checked,capacity:+$('#hcap').value});if(!r.ok)alert(r.error);loadHandler()};
window.setSt=async(id,s)=>{if(!s)return;const r=await api(`/api/reports/${id}/status`,'PATCH',{status:s});if(!r.ok)alert(r.error);loadHandler()};
// Routing
async function loadRouting(){const d=await api('/api/routing');const nm=Object.fromEntries(d.handlers.map(h=>[h.id,h.name]));
 $('#rtab').innerHTML=tbl([['Prefix',r=>esc(r.prefix)],['Zone',r=>esc(r.zone)],['Primary',r=>esc(nm[r.handler_id])],['Backup',r=>esc(nm[r.backup_id])]],d.routes)+'<p class="hint">Any other prefix (for example Z) goes to the central correction queue.</p>';
 $('#rload').innerHTML=tbl([['Handler',h=>esc(h.name)],['Zone',h=>esc(h.zone)],['Load',h=>`${h.load}/${h.capacity}`],['Available',h=>h.available?'Yes':'No'],['Backup',h=>esc(nm[h.backup_id]||'-')]],d.handlers);
 $('#rq').innerHTML=tbl([['Report',r=>esc(r.report_id)],['Priority',r=>tag(r.priority)],['Queue',r=>esc(r.queue)],['Why',r=>esc(r.routing_decision)]],d.queue);
 $('#rdec').innerHTML=tbl([['Report',r=>esc(r.report_id)],['Priority',r=>tag(r.priority)],['Decision',r=>esc(r.routing_decision)],['Time',r=>esc(r.created_at)]],d.decisions)}
// Analytics
const draw=(id,type,labels,data)=>{charts[id]?.destroy();if(window.Chart)charts[id]=new Chart($(id),{type,data:{labels,datasets:[{data,backgroundColor:['#0f6b63','#b4580b','#a32020','#5d6b69','#7aa6a0','#d9a441']}]},options:{plugins:{legend:{display:type!=='bar'}}}})};
async function loadAnalytics(){const a=await api('/api/analytics');$('#astats').innerHTML=[['Resolved',a.resolved],['Unresolved',a.unresolved],['48h SLA reports',a.sla_total],['SLA open',a.sla_open],['SLA breached',a.sla_breached]].map(s=>`<div class="stat">${s[0]}<b>${s[1]}</b></div>`).join('');
 draw('#c1','bar',a.by_zone.map(x=>x.label),a.by_zone.map(x=>x.n));draw('#c2','bar',a.by_category.map(x=>x.label),a.by_category.map(x=>x.n));draw('#c3','doughnut',['Resolved','Unresolved'],[a.resolved,a.unresolved])}
$('#reset').onclick=async()=>{if(confirm('Delete all reports and restore demo handlers?')){await api('/api/reset','POST');show('submit')}};
